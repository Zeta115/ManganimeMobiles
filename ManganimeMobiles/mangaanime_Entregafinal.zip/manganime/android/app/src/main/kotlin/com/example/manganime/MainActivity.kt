package com.example.manganime

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
